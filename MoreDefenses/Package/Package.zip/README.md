﻿# MoreDefenses

Starting with steampunk gun turrets, this mod aims to add more base defenses into the game in a dynamic way.

Showcase and full guide: https://www.youtube.com/watch?v=xA5IqVY_Msc

Tested with dedicated servers, and only required by clients. But probably don't take turrets where people don't want them.

Works very well with ValheimRAFT to create gunboats.

Discord: https://discord.gg/xcCnhNf4hN \
Trial server: Coming Soon \
Code: https://github.com/MeatwareMonster/MoreDefenses
