﻿# MoreDefenses

Adds a variety of turrets to the game in an extensible way.

Ballista and frost cannon update: https://www.youtube.com/watch?v=Cxf_YfS557k \
Showcase and full guide: https://www.youtube.com/watch?v=xA5IqVY_Msc

Recipes:

- Ballista: Bronze and Fine Wood
- Steampunk Turret: Iron and Surtling Cores
- Frost Cannon: Silver and Freeze Glands

Tested with dedicated servers, and only required by clients. But probably don't take turrets where people don't want them.

Works very well with ValheimRAFT to create gunboats.

Discord: https://discord.gg/xcCnhNf4hN \
Trial server: Coming Soon \
Code: https://github.com/MeatwareMonster/MoreDefenses
